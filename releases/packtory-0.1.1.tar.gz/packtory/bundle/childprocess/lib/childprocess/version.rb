module ChildProcess
  VERSION = '0.9.0'
end
