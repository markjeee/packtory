module FFI
  VERSION = '1.9.25'
end
