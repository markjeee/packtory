# Adding require paths to load path (empty if no gems is needed)


# == Gem: cabin, version: 0.9.0
$:.unshift File.expand_path('../../cabin/lib', __FILE__)

# == Gem: arr-pm, version: 0.0.10
$:.unshift File.expand_path('../../arr-pm/lib', __FILE__)

# == Gem: backports, version: 3.11.4
$:.unshift File.expand_path('../../backports/lib', __FILE__)

# == Gem: bundler, version: 1.16.4
$:.unshift File.expand_path('../../bundler/lib', __FILE__)

# == Gem: ffi, version: 1.9.25
$:.unshift File.expand_path('../../ffi/lib', __FILE__)

# == Gem: childprocess, version: 0.9.0
$:.unshift File.expand_path('../../childprocess/lib', __FILE__)

# == Gem: clamp, version: 1.0.1
$:.unshift File.expand_path('../../clamp/lib', __FILE__)

# == Gem: dotenv, version: 2.5.0
$:.unshift File.expand_path('../../dotenv/lib', __FILE__)

# == Gem: json, version: 1.8.6
$:.unshift File.expand_path('../../json/lib', __FILE__)

# == Gem: insist, version: 1.0.0
$:.unshift File.expand_path('../../insist/lib', __FILE__)

# == Gem: mustache, version: 0.99.8
$:.unshift File.expand_path('../../mustache/lib', __FILE__)

# == Gem: stud, version: 0.0.23
$:.unshift File.expand_path('../../stud/lib', __FILE__)

# == Gem: pleaserun, version: 0.0.30
$:.unshift File.expand_path('../../pleaserun/lib', __FILE__)

# == Gem: io-like, version: 0.3.0
$:.unshift File.expand_path('../../io-like/lib', __FILE__)

# == Gem: ruby-xz, version: 0.2.3
$:.unshift File.expand_path('../../ruby-xz/lib', __FILE__)

# == Gem: fpm, version: 1.10.2
$:.unshift File.expand_path('../../fpm/lib', __FILE__)


